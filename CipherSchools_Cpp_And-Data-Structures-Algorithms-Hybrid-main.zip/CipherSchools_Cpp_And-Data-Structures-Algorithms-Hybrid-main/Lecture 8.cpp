#include <iostream>
using namespace std;
int main(){
	int array[3]={12,14,15}; // Declare the array and Access an array element by referring to the index number.
	cout<< array[1];
	return 0;
}

#include <iostream>
using namespace std;

int main() {
  int a[4] = {1,2,3,4}; //Declare the array and access the array element by using with for loops.
  for (int i = 0; i < 4; i++) {
    cout << a[i] << endl;
  }
  return 0;
}

#include <iostream>
using namespace std;
int main(){
	int a[3] = {1,2,3};
	for(int i=0;i<3; i++){
		cout<<i<<"="<<a[i]<<endl;
	}
	return 0;
}
