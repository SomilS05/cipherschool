#include<iostream>
using namespace std;
int main(){
	for(int i=0; i<=100;i++){ //here by using the for loop print 100 numbers
		cout<<i<<endl;
	}
	return 0;
}
