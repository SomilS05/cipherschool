#include <iostream>
using namespace std;
int main(){
	for (int i = 0;i<5;i++){   // By using the for loop print the numbers from 0 to 4.
		cout<<i<<endl;
	}
	return 0;
}

#include<iostream>
using namespace std;
int main(){
	for(int i=0; i<=100;i++){ //here by using the for loop print 100 numbers
		cout<<i<<endl;
	}
	return 0;
}

#include<iostream>
using namespace std;
int main(){
	for(int i=0; i<100;i=i+2){ //here by using the for loop print the even numbers upto 100
		cout<<i<<endl;
	}
	return 0;
}
