// for Address of an elements use the ampersand symobl(&).
#include <iostream>
using namespace std;
int main(){
	int a=5;
	float b=6;
	long long c=6;
	cout<<"The address of int is "<<&(a)<<"The address of float is "<<&(b)<<"the address of long long  is "<<&(c);
	return 0;
}
