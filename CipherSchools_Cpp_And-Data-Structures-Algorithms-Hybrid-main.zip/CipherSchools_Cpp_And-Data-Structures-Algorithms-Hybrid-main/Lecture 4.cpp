#include <iostream>
using namespace std;
int main(){
	
	int a,b,c;  //Declare the 3 variables and assign the values. 
	a=5;b=5;c=6;
	
	int d=a+b-c;
	
	cout<<d;
	
	return 0;
}
