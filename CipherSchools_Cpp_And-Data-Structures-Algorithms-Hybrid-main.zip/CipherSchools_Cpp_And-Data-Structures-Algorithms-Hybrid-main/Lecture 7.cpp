#include <iostream>
using namespace std;
int main(){
	int a,b,c; // reverse the numbers 
	cin>>a>>b>>c;
	cout<<"print the numbers in reverse order "<<c<<b<<a<<endl;
	return 0;
}

// Declare the array 
#include <iostream>
using namespace std;
int main(){
	int array[5];
	
	return 0;
}
