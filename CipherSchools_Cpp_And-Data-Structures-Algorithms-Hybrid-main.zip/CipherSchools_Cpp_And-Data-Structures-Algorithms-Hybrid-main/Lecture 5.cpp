#include <iostream>
using namespace std;
int main(){
//	//Declare the 2 variables and this code for the boolean statments.whether the statments is True =1; False=0;
//	int a,b;
//	
//	cin>>a;
//	cin>>b;
//	
//	cout<<(a>b);
	// Next is Declare the 4 variables and this code for the and ,or operations.
	int a,b,c,d;
	cin>>a;
	cin>>b;
	cin>>c;
	cin>>d;
	
	cout<<(a>b&&c>d);
	cout<<(a>b ||c>d);
	
	return 0;
}
