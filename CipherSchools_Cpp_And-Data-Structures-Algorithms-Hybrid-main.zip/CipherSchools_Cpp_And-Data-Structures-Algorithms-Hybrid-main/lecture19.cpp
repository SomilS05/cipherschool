//Address of an elements.
#include <iostream>
using namespace std;
int main(){
	int a=5;
	float b=6;
	long long c=6;
	long long int d=7;
	cout<<"The size of int is "<<sizeof(a)<<"The size of float is "<<sizeof(b)<<"the size of long long  is "<<sizeof(c);
	cout<<"The size of long long int "<<sizeof(d);
	return 0;
}
